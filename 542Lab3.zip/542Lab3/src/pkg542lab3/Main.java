/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg542lab3;

import java.util.Scanner;

/**
 *
 * @author Mayank
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws InterruptedException {
        
        Owner owner=new Owner();
        Worker worker=new Worker();
        Company company=new Company();
        Manager manager=new Manager();
        Employee employee=new Employee() {};{
    };
    company.setName("ABCCO");
    company.setAddress("San Marcos,CA,USA");
    System.out.println("Welcome to " + company.getName());
    System.out.println("Located at " + company.getAddress());
    System.out.println("");
    System.out.println("----------------------");
    System.out.println("");
    System.out.println("Enter 1 for Company details");
    Scanner sc = new Scanner(System.in);
    int input = sc.nextInt();
    switch (input) {
        case 1:
            System.out.println("Craig is owner of " + company.getName());
            System.out.println(Manager.John + " and " + Manager.Mary + " are Manager of " + company.getName());
            System.out.println(Manager.John + " manages " + worker.Jack + " and " + worker.Jim);
            System.out.println(Manager.Mary + " manages " + worker.Katie + "," + worker.Amy + "," + worker.Greg + "");
            System.out.println("");
            System.out.println("");
            Thread.sleep(1000);
            System.out.println("Show All the worker's task");
            worker.showTask();
            System.out.println("");
            System.out.println("");
            Thread.sleep(1000);
            System.out.println("Show All worker's salary");
            worker.showSalary();
        default:
            break;
    }
    //Worker task Exchange
    System.out.println("");
    System.out.println("-------------------------------------------------");
    System.out.println("");
    System.out.println("Enter 1 for owner announcement");
    int announcement = sc.nextInt();
    
    switch (announcement) {
    case 1:
        owner.announceNews();
        System.out.println("");
        System.out.println("");
        System.out.println("Enter the name of worker who is on vacation");
        String wrkvacation = sc.next();
        System.out.println("Enter the name of worker who take the task of worker who is on vacation");
        String wrktake = sc.next();
        worker.isOnVacation(wrkvacation);
        System.out.println("");
        System.out.println("-------------------------------------------------");
        System.out.println("");
        System.out.println("Enter update to show updated work list");
        String update = sc.next();
        switch (update) {
            case "update":
                worker.work(wrkvacation, wrktake);
            break;
            default:
                System.out.println("Write correct keywork");
            break;
        }
    }
//Display Manager List
    System.out.println("");
    System.out.println("-------------------------------------------------");
    System.out.println("");
    System.out.println("Enter show for list of managers");
    String managerName = sc.next();
    switch (managerName) {
        case "show":
            manager.showManagerName();
        break;
        default:
            System.out.println("Enter show to show the list of manager");
        break;
    }
    //Manager Task Exchange
    System.out.println("");
    System.out.println("-------------------------------------------------");
    System.out.println("");
    System.out.println("Enter manager name who go for vacation:)");
    String managernameIsOnVacation = sc.next();
    System.out.println("");
    System.out.println("Enter the name of manager who take the duty of manager who is on vacation");
    String managerNameTakeDuty = sc.next();
    manager.isOnVacation(managernameIsOnVacation);
    //Manager updated list
    System.out.println("");
    System.out.println("-------------------------------------------------");
    System.out.println("");
    System.out.println("Enter update to show updated works of manager ");
    System.out.println("");
    String update = sc.next();
    switch (update) {
        case "update":
            System.out.println("");
            manager.updatedWork(managernameIsOnVacation, managerNameTakeDuty);
            Thread.sleep(1000);
            manager.updateSalary(employee);
        break;
        default:
            System.out.println("Enter update correctly");
        break;
    }
    //Manager's evaluations of workers
    System.out.println("");
    System.out.println("-------------------------------------------------");
    System.out.println("");
    System.out.println("Enter evaluate to see manager's evaluation of workers");
    System.out.println("");
    String evaluate = sc.next();
    switch (evaluate) {
        case "evaluate":
            manager.evaluateEmployeesPerfomance();
        break;
        default:
            System.out.println("Enter the right keywork evaluate");
        break;
    }
 }    
}
