/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg542lab3;

/**
 *
 * @author Mayank
 */
public abstract class People {
    
    static String name;
    static int phone;
    
}
