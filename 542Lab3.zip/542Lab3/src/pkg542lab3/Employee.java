/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg542lab3;

/**
 *
 * @author Mayank
 */
public abstract class Employee {
    private String name[];
    private int performanceScale;
    private static int[]salary;
    
    public int getPerformanceScale(){
        return performanceScale;
    }
    public void setPerformanceScale(int grade){
        performanceScale=grade;
    }
    
    public static int[] getSalary(){
        return salary;
    }
    
    public static void setSalary(int[]dollar){
        salary=dollar;
    }
}
