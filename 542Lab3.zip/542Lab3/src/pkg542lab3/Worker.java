/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg542lab3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Mayank
 */
public class Worker extends Employee {
    
    private int salary;
    private List<Worker>colleagues;
    Task task;
    private List tasks;
    Manager manager;
    public String TaskDone;
    public String AssignedTask;
    
    public  String getTaskDone(){
        return TaskDone;
    }
    public  String getAssignedTask(){
        return AssignedTask;
    }
    
    static String Jack = "Jack", Katie = "Katie", Amy = "Amy", Jim = "Jim", Greg = "Greg";
    static int JackId = 4, KatieId = 3, AmyId = 2, JimId = 5, GregId = 1;
    
    public void receive() {
    String an = Owner.news;
    System.out.println(an + Jack);
    System.out.println(an + Katie);
    System.out.println(an + Amy);
    System.out.println(an + Jim);
    System.out.println(an + Greg);
}
   public Worker() {
task = new Task();
tasks = new ArrayList();
manager = new Manager();
//Worker salary
int salary[] = new int[50];
salary[GregId] = 110000;
salary[AmyId] = 80000;
salary[JackId] = 60000;
salary[KatieId] = 55000;
salary[JimId] = 70000;
setSalary(salary);
}
public int getworkerid(String workerOnvacation) {
int result;
switch (workerOnvacation) {
    case "Jack":
result = 4;
break;
case "Katie":
result = 3;
break;
case "Amy":
result = 2;
break;
case "Jim":
result = 5;
break;
case "Greg":
result = 1;
break;
default:
System.out.println("Enter correct name");
return 0;
}
return result;
}
public void work(String workerOnvacation, String worktake) {
System.out.println("");
System.out.println(">>>>>>>>>" + worktake + " works on task t" + getworkerid(worktake) +
" but also works on task t" + getworkerid(workerOnvacation) + " delegated by " + workerOnvacation);
}
public void isOnVacation(String workerOnvacation) {
switch (workerOnvacation) {
case "Jack":
System.out.println("Jack is on vacation");
break;
case "Katie":
System.out.println("Katie is on vacation");
break;
case "Amy":
System.out.println(">Amy is on vacation");
break;
case "Jim":
System.out.println("Jim is on vacation");
break;
case "Greg":
System.out.println("Greg is on vacation");
break;
default:
System.out.println("Enter proper name from above list");
break;
}
}

public void showTask() {
int j[] = new int[50];
j[GregId] = GregId;
j[AmyId] = AmyId;
j[JackId] = JackId;
j[KatieId] = KatieId;
j[JimId] = JimId;
task.setTaskId(j);
int i[] = task.getTaskId();
System.out.println(Greg + " works on task t" + i[GregId]);
System.out.println(Amy + " works on task t" + i[AmyId]);
System.out.println(Jack + " works on task t" + i[JackId]);
System.out.println(Katie + " works on task t" + i[KatieId]);
System.out.println(Jim + " works on task t" + i[JimId]);
}
public void showSalary() {
int salaryE[] = getSalary();
System.out.println(Greg + " has salary of " + salaryE[GregId] + "$ per anum.");
System.out.println(Amy + " has salary of " + salaryE[AmyId] + "$ per anum.");
System.out.println(Jack + " has salary of " + salaryE[JackId] + "$ per anum.");
System.out.println(Katie + " has salary of " + salaryE[KatieId] + "$ per anum.");
System.out.println(Jim + " has salary of " + salaryE[JimId] + "$ per anum.");
}
}