/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg542lab3;

/**
 *
 * @author Mayank
 */
public class Task {
    private int[]taskId;
    private String description;
    
    public int[] returnId(){
        return taskId;
}
    
    public String getDescription(){
        return description;
    }

    public int[] getTaskId() {
        return taskId;
    }

    public void setTaskId(int[] taskId) {
        this.taskId = taskId;
}
   
}
