/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg542lab3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Mayank
 */
public class Manager extends Employee {

    private int salary;
    private final List worker;
    private List project;
    private List<Manager> colleagues;
    static String John = "John", Mary = "Mary";
    String managerTakeDuty, managerIsOnVacation;

    Scanner sc = new Scanner(System.in);

    public Manager() {
        worker = new ArrayList();
    }

    public void showManagerName() {
        System.out.println("1st Manager " + John);
        System.out.println("2nd Manager " + Mary);
    }

    public void assignTasks() {
    }

    public void isOnVacation(String managername) {
        switch (managername) {
            case "John":
                System.out.println("John is on vacation:)");
                break;
            case "Mary":
                System.out.println("Mary is on vacation:)");
                break;
            default:
                System.out.println("Something wrong:(");
                break;
        }
    }

    public int getworkerid(String workerOnvacation) {
        int result;
        switch (workerOnvacation) {
            case "Jack":
                result = 4;
                break;
            case "Katie":
                result = 3;
                break;
            case "Amy":
                result = 2;
                break;
            case "Jim":
                result = 5;
                break;
            case "Greg":
                result = 1;
                break;
            default:
                System.out.println("Enter correct name");
                return 0;
        }
        return result;
    }

    public void updatedWork(String managerIsOnVacation, String managerTakeDuty) {
        this.managerIsOnVacation = managerIsOnVacation;
        this.managerTakeDuty = managerTakeDuty;
        System.out.println("Manager " + managerIsOnVacation + " is on vacation so delegates them duty to " + managerTakeDuty);
        System.out.println("");
        System.out.println("Now manager " + managerTakeDuty + " handles All the employee.");
        System.out.println("");
        System.out.println("");
    }

    public void collectCompletedTask() {
    }

    public void evaluateEmployeesPerfomance() {
        Worker worker = new Worker();
        System.out.println("Enter show to see the manager evaluation of Employees Perfomance");
        String show = sc.next();
        switch (show) {
            case "show":
                worker.setPerformanceScale(2);
                System.out.println(Worker.Amy + " = " + worker.getPerformanceScale());
                worker.setPerformanceScale(5);
                System.out.println(Worker.Greg + " = " + worker.getPerformanceScale());
                worker.setPerformanceScale(5);
                System.out.println(Worker.Jack + " = " + worker.getPerformanceScale());
                worker.setPerformanceScale(3);
                System.out.println(Worker.Jim + " = " + worker.getPerformanceScale());
                worker.setPerformanceScale(4);
                System.out.println(Worker.Katie + " = " + worker.getPerformanceScale());
                break;
            default:
                System.out.println("Enter correct keyword");
                break;
        }
    }

    public void updateSalary(Employee e) {
        System.out.println("");
        System.out.println("-----");
        System.out.println("");
        System.out.println("Enter the name of Employee who's salary increse by " + managerTakeDuty);
        String employeeName = sc.next();
        System.out.println("");
        int temp[] = new int[50];
        Employee myObj = new Employee() {
        };
        temp = Employee.getSalary();
        temp[getworkerid(employeeName)] = temp[getworkerid(employeeName)] + 1000;
        System.out.println("");
        System.out.println("Worker " + employeeName + "'s salary is incremented by 1000$ by manager " + managerTakeDuty);
        System.out.println("Updated salary of worker " + employeeName + " is" + temp[getworkerid(employeeName)] + "$ per anum.");
    }
}
