/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg542lab3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Mayank
 */
public class Owner extends People {
    
    Worker worker=new Worker();
    
    int i=1;
    static String news;
    private  List company;
    private List manager;
    
    public Owner(){
        
        company=new ArrayList();
        manager=new ArrayList();
    }
    public void startProject(){
    }
    public void evaluateManagerPerformance(){
    }
    public void updateSalary(Manager m){
    }
    public void announceNews(){
        news="Good Job";
        worker.receive();
    }
}
