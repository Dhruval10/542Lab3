/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg542lab3;

/**
 *
 * @author Mayank
 */
public class Company {
    
   private String name;
   private String address;
   private Owner owner;
   
   public Company(){
       owner=new Owner();
       
   }    

   public String getName(){
    return  name;
}

     public void setName(String Name){
        this.name=Name;
}

public String getAddress(){
return address;
}

    void setAddress(String address){
        this.address=address;
}
}

